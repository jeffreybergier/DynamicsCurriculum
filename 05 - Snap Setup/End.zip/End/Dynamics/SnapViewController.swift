//
//  SnapViewController.swift
//  Dynamics
//
//  Created by Jeffrey Bergier on 9/5/15.
//  Copyright © 2015 Saturday Apps. All rights reserved.
//

import UIKit

class SnapViewController: UIViewController {
    
    @IBOutlet weak var snapMeSurroundView: UIView?
    @IBOutlet weak var snapPointView: UIView?
    
    lazy var animator: UIDynamicAnimator = UIDynamicAnimator(referenceView: self.view)
    lazy var snapBehavior: UISnapBehavior = {
        let snap = UISnapBehavior(item: self.snapMeSurroundView!, snapToPoint: self.lastSnapPoint)
        snap.damping = 0.4
        return snap
    }()
    
    var lastSnapPoint = CGPointZero {
        didSet {
            let radius = CGFloat(10)
            self.snapPointView?.frame = CGRect(
                x: self.lastSnapPoint.x - radius,
                y: self.lastSnapPoint.y - radius,
                width: radius * 2,
                height: radius * 2
            )
            self.snapPointView?.layer.cornerRadius = 10
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
                
        self.lastSnapPoint = self.view.center
        self.animator.addBehavior(self.snapBehavior)
    }
    
    @IBAction func didTapOnView(sender: UITapGestureRecognizer) {
        self.lastSnapPoint = sender.locationInView(self.view)
        self.snapBehavior.snapPoint = lastSnapPoint
    }
    
    @IBAction func didTouchSnapView(sender: UIPanGestureRecognizer) {
        switch sender.state {
        case .Changed:
            let touchLocation = sender.locationInView(self.view)
            self.snapBehavior.snapPoint = touchLocation
        case .Ended, .Failed, .Cancelled:
            self.snapBehavior.snapPoint = self.lastSnapPoint
        case .Possible, .Began:
            break
        }
    }
}
